
var moment = require('moment');
var a=moment("2018/5/31 11:13:30").format("HH:mm:ss");


console.info(a);